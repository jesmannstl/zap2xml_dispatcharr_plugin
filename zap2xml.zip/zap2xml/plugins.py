# Display metadata for Dispatcharr plugin registry/UI
__all__ = ['PLUGIN_KEY', 'PLUGIN_NAME', 'PLUGIN_VERSION']
PLUGIN_KEY = 'zap2xml'
PLUGIN_NAME = 'Zap2XML'
PLUGIN_VERSION = '2.1.4'
__version__ = PLUGIN_VERSION
version = PLUGIN_VERSION
